# Internationalization and Localization

### Internationalization is a mechanism to create such an application that can be adapted to different languages and regions.

### Internationalization is one of the powerful concept of java if you are developing an application and want to display messages, currencies, date, time etc. according to the specific region or language.

### Localization is the mechanism to create such an application that can be adapted to a specific language and region by adding locale-specific text and component.

### An object of Locale class represents a geographical or cultural region. This object can be used to get the locale specific information such as country name, language, variant etc.
